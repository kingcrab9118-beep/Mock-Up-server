import { Module } from '@nestjs/common';
import { WsMockModule } from './ws_mock/ws_mock.module';

@Module({
  imports: [WsMockModule],
})
export class AppModule {}
